import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import psycopg2

load_dotenv()

app = Flask(__name__, static_folder='frontend', static_url_path='')
CORS(app)

def get_db_connection():
    return psycopg2.connect(
        host=os.getenv("DB_HOST"),
        database=os.getenv("DB_NAME"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        port=os.getenv("DB_PORT")
    )


@app.route('/')
def serve_index():
    return app.send_static_file('index.html')

@app.route('/api/retos', methods=['GET'])
def get_retos():
    categoria = request.args.get('categoria')
    dificultad = request.args.get('dificultad')

    conn = get_db_connection()
    cur = conn.cursor()

    query = "SELECT * FROM retos"
    filters = []
    params = []

    if categoria:
        filters.append("categoria = %s")
        params.append(categoria)
    if dificultad:
        filters.append("dificultad = %s")
        params.append(dificultad)

    if filters:
        query += " WHERE " + " AND ".join(filters)

    query += " ORDER BY id;"

    cur.execute(query, tuple(params))
    retos = cur.fetchall()
    cur.close()
    conn.close()

    retos_list = [{
        'id': r[0],
        'titulo': r[1],
        'descripcion': r[2],
        'categoria': r[3],
        'dificultad': r[4],
        'estado': r[5]
    } for r in retos]

    return jsonify(retos_list)

@app.route('/api/retos', methods=['POST'])
def add_reto():
    data = request.json
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        'INSERT INTO retos (titulo, descripcion, categoria, dificultad, estado) VALUES (%s, %s, %s, %s, %s) RETURNING id;',
        (data['titulo'], data['descripcion'], data['categoria'], data['dificultad'], data['estado'])
    )
    new_id = cur.fetchone()[0]
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'id': new_id}), 201

@app.route('/api/retos/<int:reto_id>', methods=['PUT'])
def update_reto(reto_id):
    data = request.json
    nuevo_estado = data.get('estado')
    if not nuevo_estado:
        return jsonify({'error': 'Estado es requerido'}), 400

    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            'UPDATE retos SET estado = %s WHERE id = %s RETURNING *;',
            (nuevo_estado, reto_id)
        )
        reto_actualizado = cur.fetchone()
        conn.commit()
        cur.close()
        conn.close()

        if reto_actualizado:
            return jsonify({'message': 'Estado actualizado correctamente'})
        else:
            return jsonify({'error': 'Reto no encontrado'}), 404
    except Exception as e:
        print("Error al actualizar estado:", e)
        return jsonify({'error': 'Error en servidor'}), 500


# Ruta para eliminar reto
@app.route('/api/retos/<int:reto_id>', methods=['DELETE'])
def delete_reto(reto_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM retos WHERE id=%s;', (reto_id,))
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'message': 'Reto eliminado correctamente'})

if __name__ == '__main__':
    app.run(debug=True)
