const API_URL = "http://localhost:5000/api/retos";
const form = document.getElementById('challenge-form');
const message = document.getElementById('message');

form.addEventListener('submit', async e => {
  e.preventDefault();

  const data = {
    titulo: form.title.value.trim(),
    descripcion: form.description.value.trim(),
    categoria: form.category.value,
    dificultad: form.difficulty.value,
    estado: form.status.value
  };

  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    if (!res.ok) throw new Error('Error, vuelva a intentarlo');

    message.textContent = 'Reto Creado';
    message.style.color = 'green';
    form.reset();

  } catch (err) {
    message.textContent = err.message;
    message.style.color = 'red';
  }
});
