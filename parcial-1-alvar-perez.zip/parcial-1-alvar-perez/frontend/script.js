const API_URL = "http://localhost:5000/api/retos"; 

const challengeList = document.getElementById("challenge-list");
const filterCategory = document.getElementById("filter-category");
const filterDifficulty = document.getElementById("filter-difficulty");
const applyFiltersBtn = document.getElementById("apply-filters");
const clearFiltersBtn = document.getElementById("clear-filters");

function capitalize(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

async function fetchChallenges(category = "", difficulty = "") {
  let url = API_URL;
  const params = [];
  if (category) params.push(`categoria=${encodeURIComponent(category)}`);
  if (difficulty) params.push(`dificultad=${encodeURIComponent(difficulty)}`);
  if (params.length) url += "?" + params.join("&");
  const res = await fetch(url);
  if (!res.ok) {
    challengeList.innerHTML = "<p>error.</p>";
    return;
  }
  const retos = await res.json();
  challengeList.innerHTML = "";
  if (!retos.length) {
    challengeList.innerHTML = "<p>No hay mas retos para mostrar.</p>";
    return;
  }

  retos.forEach(reto => {
    const div = document.createElement("div");
    div.className = "challenge-item";

    div.innerHTML = `
      <h3 class="challenge-title">Título: ${capitalize(reto.titulo)}</h3>
      <p><strong>Descripción:</strong> ${capitalize(reto.descripcion)}</p>
      <p><strong>Categoría:</strong> ${capitalize(reto.categoria)}</p>
      <p><strong>Dificultad:</strong> ${capitalize(reto.dificultad)}</p>
      <div class="challenge-footer">
        <p><strong>Estado:</strong> <span class="estado-badge estado-${reto.estado.replace(/\s/g, '-')}">${capitalize(reto.estado)}</span></p>
        <select onchange="updateStatus(${reto.id}, this.value)">
          <option value="">Cambiar estado</option>
          <option value="pendiente">Pendiente</option>
          <option value="en proceso">En proceso</option>
          <option value="completado">Completado</option>
        </select>
        <button onclick="deleteChallenge(${reto.id})" style="background:#dc3545;">Eliminar</button>
      </div>
    `;

    challengeList.appendChild(div);
  });
}

async function updateStatus(id, status) {
  if (!status) return; 

  try {
    const res = await fetch(`${API_URL}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ estado: status })
    });
    if (!res.ok) throw new Error("Error actualizando estado");
    fetchChallenges(filterCategory.value, filterDifficulty.value);
  } catch (err) {
    alert(err.message);
  }
}

async function deleteChallenge(id) {
  if (!confirm("esta seguro de eliminar este reto?")) return;
  try {
    const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    if (!res.ok) throw new Error("Fallo al eliminar, vuelva a intentarlo");
    fetchChallenges(filterCategory.value, filterDifficulty.value);
  } catch (err) {
    alert(err.message);
  }
}

applyFiltersBtn.addEventListener("click", () => {
  fetchChallenges(filterCategory.value, filterDifficulty.value);
});

clearFiltersBtn.addEventListener("click", () => {
  filterCategory.value = "";
  filterDifficulty.value = "";
  fetchChallenges();
});

fetchChallenges();
